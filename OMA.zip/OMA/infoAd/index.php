<?php
include('C:\OSPanel\domains\Chacha\avtor/session.php');
	$id=$_GET['id'];


$link = mysqli_connect("127.0.0.1", "root", "", "SaitOB");
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
	$sql = "SELECT * FROM `Photos` JOIN `Advertisement` ON `Advertisement`.`id_Ad`=`Photos`.`id_Advertisement` WHERE `Advertisement`.`id_Ad`=".$id."";
	$result = mysqli_query($link, $sql);
        $row = mysqli_fetch_array($result);
            $val="SELECT * FROM `Currency` WHERE `id`=".$row['idCurrency'].""; 
            if ($r=mysqli_query($link,$val))
            {
                $vall=mysqli_fetch_array($r);
            }
             else {$vall['name']=" ";}




 ?>


<!doctype html>
<html lang="en">
  <head>
    <title>Информация об объявлении</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="pros.css">
    <link href="image/favicon.ico" rel="shortcut icon" type="imgage/x-icon" />
  </head>

  <body>
  <header>
    <nav class="navbar fixed-top navbar-light bg-light">
<a <?echo "href='http://chacha:81/'";?> title="На главную" id="logo">o</a>
<a <?echo "href='http://chacha:81/'";?> title="На главную" id="logo1">M</a>
<a <?echo "href='http://chacha:81/'";?> title="На главную" id="logo2">a</a>
<?if (!isset($login_session)){?>
<span><a href="/avtor/" class="wer" title="Подача Объявления">Подать Объявление</a></span><input type="text" class="field" placeholder="Что ищем, дружище?"/>
<?} else {?>
<span><a <?echo "href='/Add/'";  ?> class="wer" title="Подача Объявления">Подать Объявление</a></span><input type="text" class="field" placeholder="Что ищем, дружище?"/>
<?}?>


                  <? if(!isset($login_session)){
                                            ?>
<span class='right'><span class='contact'><a href='http://chacha:81/registration/' title='Зарегистрироваться'>Регистрация</a></span></span>
<span class='right'><span class='contact'><a href='//chacha:81/avtor/' title='Войти'>Вход</a></span></span>
                <?
                }
                else {
                        $Request="SELECT * from user where idUser=$login_session";
                        $result_of_Request=mysqli_query($link,$Request);
                        $user_data_array=mysqli_fetch_array($result_of_Request);
                        $username=$user_data_array['username']; 
                    echo "<span class='right'><span class='contact'><a href='' title=''>".$username."</a></span></span>";
                    echo "<span class='right'><span class='contact'><a href='/avtor/logout.php' title=''>Выйти</a></span></span>";
                }
?>
</nav>
</header>
<center><h1 class="jalko">Информация об объявлении</h1></center>
<div class="podacha">
	<h1><?echo $row['Zagolovok']?></h1>
	<p><?echo $row['Date'];?></p>	
<img <?echo "src='http://chacha:81/Add/".$row['Photo']."'";?> width="636" height="357" alt="..." class="photo">
 <div class="vot">
 	<p><?echo $row['Description']?></p>
<?
   $val="SELECT * FROM `Currency` WHERE `id`=".$row['idCurrency'].""; 
            if ($r=mysqli_query($link,$val))
            {
                $vall=mysqli_fetch_array($r);
            }
            else {$vall['name']=" ";}
            ?>
     <p>Цена:	
      <span class="cena"><? echo $row['Price']." ".$vall['name'];?></span>
      	 <? $s="SELECT * FROM City WHERE idCity=".$row['City']."";
       			$r = mysqli_query($link, $s);
        $ro = mysqli_fetch_array($r);
        		?>
       <span class="gorod">Город: <span><? echo $ro['name'];?></span></span>
        
       <? /*$s="SELECT * FROM user WHERE idUser=".$row['advertiser']."";
       			$r = mysqli_query($link, $s);
        $ro = mysqli_fetch_array($r);
            */
       ?>
       
        <span class="gorod">Продавец: <span><? echo $row['Seller'];?></span></span>
     </p>
      <p class="nomer">
       <button type="button" class="btn btn-success" id="but" value="Номер телефона" onclick="nomer()"><p id="nom">Показать Номер</p></button>
       <span class="jaloba"><button type="button" class="btn btn-warning">Пожаловаться на объявление</button>
       </span>
      </p>
  </div>
</div>

			




    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popperjs, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
  <script type='text/javascript'>
  function nomer() {
  $('#nom').text(<?echo "'".$row['Contacts']."'"?>);
}
</script>

  </body>
</html>

<?php
		$id = $_GET['id'];
  ?>
  <!DOCTYPE html>
  <html>
  <head>
  	<title></title>
  	<meta charset="utf-8">
  </head>
  <body>
  	<center>
  		<?php
$link = mysqli_connect("127.0.0.1", "root", "", "SaitOB");
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
	$sql = "SELECT * FROM `Photos` JOIN `Advertisement` ON `Advertisement`.`id_Ad`=`Photos`.`id_Advertisement` WHERE `Advertisement`.`id_Ad`=".$id."";
	$result = mysqli_query($link, $sql);
        $row = mysqli_fetch_array($result);
            $val="SELECT * FROM `Currency` WHERE `id`=".$row['idCurrency'].""; 
            if ($r=mysqli_query($link,$val))
            {
                $vall=mysqli_fetch_array($r);
            }
            else {$vall['name']=" ";}
            echo "<img src='".$row['Photo']."'>";
            echo "<h2>".$row['Description']."</h2>";

            ?>	
  	</center>
  </body>
  </html>
<!DOCTYPE html>
<html>
<head>
	<title>Проверка</title><script src="jquery-3.2.1.js"></script>
	<script>
		function sub(){
			var ttt = document.getElementById('name').value;
			$.ajax({
			type: "POST",
			url: "feedback.php",
			data: {'name':ttt},
			success:function(data)
			{
				if (data=="Super"){
				alert(data);
				}
				else {
					alert("apapap");
				}
			}
		});
		};
	</script>
</head>
<body>
	<input type="text" name="name" id="name">
	<input type="button" name="" onclick="sub()">

</body>
</html>
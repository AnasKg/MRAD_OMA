<?
	if (isset($_POST['name']))
	{
		if ($_POST['name']=='Anas')
		{
			echo "Super";
		}
		else {
			echo "No";
		}
	}
	else {echo "Error";}
?>
<?php
include('avtor/session.php');
$link = mysqli_connect("127.0.0.1", "root", "", "SaitOB");
 
// Check connection
if($link === false){
    echo "Сайт временно не доступен!";
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>
<!DOCTYPE html>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="keywords" content="test, site, website"/>
<meta name="description" content="Этот сайт является пробным сайтом"/>

<link href="Style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="css/bootstrap.css">
<link href="image/favicon.ico" rel="shortcut icon" type="image/x-icon" />

	<title>oMa</title>

</head>

<body>


<header>
    <nav class="navbar fixed-top navbar-light bg-light">
<a <?echo "href='http://chacha:81/'";?> title="На главную" id="logo">o</a>
<a <?echo "href='http://chacha:81/'";?> title="На главную" id="logo1">M</a>
<a <?echo "href='http://chacha:81/'";?> title="На главную" id="logo2">a</a>
<?if (!isset($login_session)){?>
<span><a href="/avtor/" class="wer" title="Подача Объявления">Подать Объявление</a></span><input type="text" class="field" placeholder="Что ищем, дружище?"/>
<?} else {?>
<span><a <?echo "href='/Add/'";  ?> class="wer" title="Подача Объявления">Подать Объявление</a></span><input type="text" class="field" placeholder="Что ищем, дружище?"/>
<?}?>


                  <? if(!isset($login_session)){
                                            ?>
<span class='right'><span class='contact'><a href='http://chacha:81/registration/' title='Зарегистрироваться'>Регистрация</a></span></span>
<span class='right'><span class='contact'><a href='//chacha:81/avtor/' title='Войти'>Вход</a></span></span>
                <?
                }
                else {
                        $Request="SELECT * from user where idUser=$login_session";
                        $result_of_Request=mysqli_query($link,$Request);
                        $user_data_array=mysqli_fetch_array($result_of_Request);
                        $username=$user_data_array['username']; 
                    echo "<span class='right'><span class='contact'><a href='' title=''>".$username."</a></span></span>";
                    echo "<span class='right'><span class='contact'><a href='/avtor/logout.php' title=''>Выйти</a></span></span>";
                }
?>
</nav>
</header>

<div id="wrapper"> 
	<div id="articles">
		<ul> 
			<?
			$sql = "SELECT  * FROM `Photos` INNER JOIN `Advertisement` ON `Advertisement`.`id_Ad` = `Photos`.`id_Advertisement` WHERE `Photos`.`Status` = 1 ORDER BY  `Photos`.`id_Photos` DESC";

if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_array($result)){
            $val="SELECT * FROM `Currency` WHERE `id`=".$row['idCurrency'].""; 
            if ($r=mysqli_query($link,$val))
            {
                $vall=mysqli_fetch_array($r);
            }
            else {$vall['name']=" ";}
            echo "<li>";
            	echo "<a href='http://chacha:81/infoAd/index.php?id=".$row['id_Ad']."'>";
            	?>
            		<div class="obfoto" style="background-image: url(<? echo "'Add/".$row['Photo']."'";?>);">
						<div class="price"><?echo $row['Price'];?>
								<span class="currency"><? echo $vall['name'];?></span>
						</div>
					</div>
					<div class="opisanie">
						<?echo $row['Zagolovok'];?>
					</div>
					<div class="date">
						<? echo $row['Date'];?>
					</div>
				</a>
            	<?
            echo "</li>";
            	//echo "<a href='infoAd.php?id=".$row['id_Ad']."'><img src='".$row['Photo']."'> <h2>".$row['Description']."</h2></a>";
            	//echo "<p>".$row['Price'], $vall['name']."</p> </li>";

        }
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
mysqli_close($link);
?>
</div>
</div>
<footer>
<span class="left">Все права защищены &copy; 2017</span>
<span class="right"><a href="https://www.instagram.com/sadabaevb/"><img src="image/insta.ico" alt="Инстаграм" title="Инстаграм"></a></span>
</footer>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
</body>
</html>
<?php
$link = mysqli_connect("127.0.0.1", "root", "", "SaitOB");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
$phonenumber = mysqli_real_escape_string($link, $_REQUEST['phonenumberoremail']);
$password = mysqli_real_escape_string($link, $_REQUEST['password']);
 

$sql = "SELECT * FROM user";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_array($result)){
            if ($row['Number']===$phonenumber or $row['Email'])
            {
            	if ($row['password']===$password)
            	{
            		 header("Location:http://chacha:81/index.php?id=".$row['idUser']."");

            	}
            }
        }
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>
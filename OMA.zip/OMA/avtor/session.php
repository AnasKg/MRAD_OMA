<?php
	$cone = mysqli_connect("127.0.0.1", "root", "", "SaitOB");
	session_start();
	$user_check=$_SESSION['login_user'];
	$check_zapros=mysqli_query($cone,"SELECT * from user where `Number` = '$user_check' or `Email`='$user_check'");
	$row = mysqli_fetch_assoc($check_zapros);
	$login_session =$row['idUser'];
	if(!isset($login_session)){
		mysqli_close($cone); // Closing Connection
		//header('Location: http://chacha:81/');
	}
?>
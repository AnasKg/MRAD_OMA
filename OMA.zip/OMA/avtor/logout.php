<?php
session_start();
if(session_destroy()) // Destroying All Sessions
{
header("Location:http://chacha:81/"); // Redirecting To Home Page
}
?>
<?php
	session_start();
	$errorforemail='';
	$errorforpassword='';
	if (isset($_POST['submit']))
	{
		if (empty($_POST['phonenumberoremail']) || empty($_POST['password']))
		{

			$errorforemail="Неверный Email или номер телефона";
			$errorforpassword="Неверный пароль";
		}
		else 
		{
			$phonenumberoremail=$_POST['phonenumberoremail'];
			$password=$_POST['password'];
			$conectt = mysqli_connect("127.0.0.1", "root", "", "SaitOB");
			if($conectt === false){
    			die("ERROR: Could not connect. " . mysqli_connect_error());
				}
			
			$phonenumberoremail=mysqli_real_escape_string($conectt,$phonenumberoremail);
			$password=mysqli_real_escape_string($conectt,$password);

			$zapros_phone_and_email="SELECT * FROM  user WHERE `Number`='$phonenumberoremail'";
			if ($query_of_email=mysqli_query($conectt,$zapros_phone_and_email)){
			$rows_of_phone_or_email=mysqli_num_rows($query_of_email);
			if ($rows_of_phone_or_email===1)
			{
				$rows_of_phone_or_email=mysqli_fetch_array($query_of_email);
				if ($rows_of_phone_or_email['password']===$password){
				$_SESSION['login_user']=$phonenumberoremail;
				header("location:http://chacha:81/");
				}
				else 
				{
					$errorforpassword="Неверный пароль";
				}

			}
			else 
			{
				$errorforemail="Неверный Email или номер телефона";
				$errorforpassword="Неверный пароль";
			}

			}
			else { echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);

			mysqli_close($link);
			}
		}
	}
  ?>
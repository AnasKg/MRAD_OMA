<?php
include('C:\OSPanel\domains\Chacha\avtor/session.php');
include('C:\OSPanel\domains\Chacha\Add\dop.php');

      $id=$_GET['id'];
$link = mysqli_connect("127.0.0.1", "root", "", "SaitOB");

if($link === false){
	echo "Сайт временно не доступен!";
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 ?>

<!doctype html>
<html lang="en">
  <head>
    <title>Добавить новое объявление</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="Style.css">

    <script>
    function obmanul(evv)
    {
      $vyborcatt=evv.id;
      clickopen(evv);

    }
  </script>
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
-->

  </head>
  <script>
    function obmanul(evv)
    {
      $vyborcatt=evv.id;
      clickopen(evv);

    }
  </script>

    <nav class="navbar fixed-top navbar-light bg-light">
<a <?echo "href='http://chacha:81/'";?> title="На главную" id="logo">o</a>
<a <?echo "href='http://chacha:81/'";?> title="На главную" id="logo1">M</a>
<a <?echo "href='http://chacha:81/'";?> title="На главную" id="logo2">a</a>
<?if (!isset($login_session)){?>
<span><a href="/avtor/" class="wer" title="Подача Объявления">Подать Объявление</a></span><input type="text" class="field" placeholder="Что ищем, дружище?"/>
<?} else {?>
<span><a <?echo "href='/Add/'";  ?> class="wer" title="Подача Объявления">Подать Объявление</a></span><input type="text" class="field" placeholder="Что ищем, дружище?"/>
<?}?>


                  <? if(!isset($login_session)){
                                            ?>
<span class='right'><span class='contact'><a href='http://chacha:81/registration/' title='Зарегистрироваться'>Регистрация</a></span></span>
<span class='right'><span class='contact'><a href='//chacha:81/avtor/' title='Войти'>Вход</a></span></span>
                <?
                }
                else {
                        $Request="SELECT * from user where idUser=$login_session";
                        $result_of_Request=mysqli_query($link,$Request);
                        $user_data_array=mysqli_fetch_array($result_of_Request);
                        $username=$user_data_array['username']; 
                    echo "<span class='right'><span class='contact'><a href='' title=''>".$username."</a></span></span>";
                    echo "<span class='right'><span class='contact'><a href='/avtor/logout.php' title=''>Выйти</a></span></span>";
                }
?>
</nav>
  <body>
    <div class="container" style="margin-top: 4%;">
      <div class="row">
        <div class="col">
          <center>
          <h2>Добавить новое объявление</h2>
        </center>
        </div>
      </div>
    </div>
    
    <div class="container">
       <div class="row">
          <div class="col">
            <div class="adpost">
              <center>
                <form method="post" enctype="multipart/form-data" <? echo "action='kak.php'";?> id="needs-validation" novalidate><br>

                        <div class="form-group row">
                    <label for="kartinka" class="col-3 col-form-label" style="text-align: right;">Загрузить фото <span class="zvezd">*</span></label>
                      <div class="col-1">
                        <input type="file" name="kartinka" accept="image/*,image/jpeg" required>
                        <div class="invalid-feedback" >
                          Загрузите изображение.
                         </div>

                      </div>
                  </div>
                    

                  <div class="form-group row">
                    <label for="zagolovok" class="col-3 col-form-label" style="text-align: right;">Заголовок <span class="zvezd">*</span></label>
                      <div class="col-6">
                        <input class="form-control" name="zagolovok" type="text" required>
                        <div class="invalid-feedback" >
                          Дайте заголовок.
                         </div>
                       </div>
                  </div>

                  <div class="form-group row">
                    <label for="opisanie" class="col-3 col-form-label" style="text-align: right;">Описание <span class="zvezd">*</span></label>
                      <div class="col-6">
                        <textarea class="form-control" name="opisanie" rows="3" required></textarea>
                        <div class="invalid-feedback" >
                          Дайте описание.
                         </div>
                      </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-3 col-form-label" style="text-align: right;">Категория <span class="zvezd">*</span></label>
                      <div class="col-1">
                        <button type="button" class="btn btn-success" data-toggle="modal" data-target=".bd-example-modal-lg">Выбрать</button>
                      </div>
                       <div class="col-5">
                        <div id="haha" class="vali"></div>
                        <p id="selectedcategory"></p>
                        
                      </div>
                  </div>
                    <input class="form-control" type="hidden" id="vyborrazdela" name="razdel" value="">
                    <input class="form-control" type="hidden" id="vyborkategorii" name="kategoria" value="" >


                  <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" id="myLargeModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">
                        <div class="modal-header">
                         <h5 class="modal-title" id="exampleModalLongTitle">Выберите раздел</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                            <div class="modal-body">
                            	<?
                            		$sql="SELECT * FROM `Section`";
                            		$result = mysqli_query($link, $sql);
                            	?>
                                          <div class="container">
                                            <div class="row">
                                               							<? while($row = mysqli_fetch_array($result)){
                               								?>
                                                    <div class="col-4"> 
                                                        <button name="razdel" type="button" id=<?echo "'".$row['Section']."'";?>  class="btn btn-outline-success-my" onclick="obmanul(this)"  data-toggle="modal" data-target="#secondmodall" data-content=<?echo "'".$row['Section']."'";?> >
                                                        	<?php echo $row['Section']; ?>
                                                        </button>
                                                      </div>
                                                        <?
                                                    		}
                                                        ?>
                                               
                                                </div>
                                              </div>
                            </div>
                      </div>
                    </div>
                  </div>
                 

                  <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"  id="secondmodall" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                         <h5 class="modal-title" id="myLargeModalLabel1"></h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                            <div class="modal-body">
                                <? 
                                  if ($vyborcatt!=""){
                                    $zaprosRazdel="SELECT * FROM `Section` INNER JOIN `Category` ON `Section`.`id_section` = `Category`.`idSection` WHERE `Section`.`Section` = '".$vyborcatt."'";

                                      $resultRazdel = mysqli_query($link, $zaprosRazdel);
                                  
                                ?>
                                    <ul id="forul">
                                          <?while($row2 = mysqli_fetch_array($resultRazdel)){   
                                           ?>
                                      <li class="forli">
                                          <a id=<?echo "'".$row2['id_Category']."'";?>  class="selectcategoria" data-content=<?echo "'".$row2['Category']."'";?> name="kategoria"><?php echo $row2['Category'];?></a>
                                      </li>
                                      <?
                                      }
                                    }else {echo "Упс";}
                                    
                                      ?>
                                    </ul>
                            </div>
                      </div>
                    </div>
                  </div>
                
                  <div class="form-group row">
                    <label for="sena"  class="col-3 col-form-label" style="text-align: right;">Цена <span class="zvezd">*</span></label>
                      <div class="col-3">
                      <input class="form-control" id="sena" name="sena" type="number" min="1" max="999999999" placeholder="Договорная">
                      </div>
                       <div class="form-group">
                        <select class="form-control"  name="valyuta">
                        <option>СОМ</option>
                        <option>$</option>
                        </select>
                      </div>
                  </div>
                  <div class="form-group row">
                    <label for="city" class="col-3 col-form-label" style="text-align: right;">Выберите город <span class="zvezd">*</span></label>
                      <div class="col-6">
                      <select class="form-control" id="city" name="city" required>

                        <? $city="SELECT * FROM `City`";
                            $mas=mysqli_query($link,$city);
                            while ($yes=mysqli_fetch_array($mas)) {
                              ?>
                              <option><?echo $yes['name'];?></option>
                              <?
                            }
                        ?>
                      </select>
                      <div class="invalid-feedback" >
                          Укажите город.
                         </div>
                      </div>
                  </div>
                  <div class="form-group row">
                    <label for="imya" class="col-3 col-form-label" style="text-align: right;">Имя<span class="zvezd">*</span></label>
                      <div class="col-6">
                        <input class="form-control" type="text" id="imya" name="imya" required>
                        <div class="invalid-feedback">
                          Укажите имя.
                         </div>
                       </div>
                  </div>
                  <div class="form-group row">
                    <label for="number1" class="col-3 col-form-label" style="text-align: right;">Номер</label>
                      <div class="col-6">
                        <input class="form-control" type="number" id="number1" name="number" value="" placeholder="+996 123 456" required>
                        <div class="invalid-feedback">
                          Укажите номер.
                         </div>
                      </div>
                  </div>
                  

                  <div class="form-group row">
                    <label for="email" class="col-3 col-form-label" style="text-align: right;">Email address</label>
                      <div class="col-6">
                        <input type="email" class="form-control" id="email" name="email" value="" placeholder="name@example.com" required>
                         <div class="invalid-feedback">
                          Введите корректный email.
                         </div>
                      </div>
                  </div>
            <button type="submit" class="btn btn-outline-success">Опубликовать объявление</button>
        </form>
    </center>
         </div>
   </div>
  </div>
</div>
      <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script>
  (function() {
  'use strict';

  window.addEventListener('load', function() {
    var form = document.getElementById('needs-validation');
    var ppp=document.getElementById('vyborkategorii');
    var haha=document.getElementById('haha')
    form.addEventListener('submit', function(event) {
      if (ppp.value=="")
      {
        haha.textContent="Выберите раздел";
      }
      else {haha.textContent="";}
      if (form.checkValidity() === false) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    }, false);
  }, false);
})();
</script>
  
 <script src="jquery-3.2.1.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
    <script src="bootstrap.bundle.js"></script>
    <script src="bootstrap.js"></script>
     <script src="jav.js"></script>
        
       
  </body>
</html>


function clickopen(evv)
{
  alert(evv.id);
  var knopka=evv.id;
  alert(knopka);
  $.ajax({
          type: "POST",
          url: "dop.php",
          data: {'knopka':knopka},
          success:function(data)
          {
            alert(data);
          },
          error:function()
          {
            alert("error");
          }
  });
  secondmodal();
}
function secondmodal() {
   
	$("#myLargeModalLabel").modal('toggle');

	//$("#secondmodall").show();
}

$('#secondmodall').on('show.bs.modal', function (event) {
  // получить кнопку, которая его открыло
  var button = $(event.relatedTarget);
  // извлечь информацию из атрибута data-content
  var content = button.data('content');
  $('#vyborrazdela').val(content);
    
    /*$.ajax({
    type: "POST",
    url: "/dop.php",
    data: content,
    success: function (response) {
        response = JSON.parse(response);
        console.log(response);
        alert(response);
    },

    error: function () {
        alert('ошибка');
    }
    */


  // вывести эту информацию в элемент, имеющий id="content"
  $(this).find('#content').text(content);
   $(this).find('#myLargeModalLabel1').text(content); 

});  

$(function(){
	var idddd;
    $(".selectcategoria").on("click", function(){
        var cat=$(this).data('content'); 
        id = $(this).attr("id");
        $('#vyborkategorii').val(id);
        var razdel2=document.getElementById('myLargeModalLabel1');
        $("#secondmodall").modal('toggle');
        var val=document.getElementById('selectedcategory');
        var vals=document.getElementById('vyborrazdela');
        var haha=document.getElementById('haha')

        vals.value="true";
        haha.textContent="";
        val.textContent=razdel2.textContent+'-->'+cat;

    });
});


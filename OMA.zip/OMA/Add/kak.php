<?php 
include('C:\OSPanel\domains\Chacha\avtor\session.php');
$link = mysqli_connect("127.0.0.1", "root", "", "SaitOB");
 
// Check connection
if($link === false){
	echo "Сайт временно не доступен!";
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

		$kartinka = mysqli_real_escape_string($link, $_REQUEST['kartinka']);
		$zagolovok = mysqli_real_escape_string($link, $_REQUEST['zagolovok']);
		$opisanie = mysqli_real_escape_string($link, $_REQUEST['opisanie']);
    $sena = mysqli_real_escape_string($link, $_REQUEST['sena']);
    $valyuta = mysqli_real_escape_string($link, $_REQUEST['valyuta']);
    $razdel=mysqli_real_escape_string($link, $_REQUEST['razdel']);
    $kategoria = mysqli_real_escape_string($link, $_REQUEST['kategoria']);
    $selectedcity=mysqli_real_escape_string($link, $_REQUEST['city']);
    $imya = mysqli_real_escape_string($link, $_REQUEST['imya']);
    $number = mysqli_real_escape_string($link, $_REQUEST['number']);
    $email = mysqli_real_escape_string($link, $_REQUEST['email']);
    if ($sena!=="")
    {
        if($valyuta==="$")
        {
          $valyuta="2";
        }
        else 
        {
          $valyuta="1";
        }
    }
    else {
      $valyuta="";
    }
     if ($selectedcity==="")
     {
      $selectedcity="Бишкек";
     }
     				$s="SELECT * FROM City WHERE name='".$selectedcity."'";
     				if ($r=mysqli_query($link,$s))
     				{
     					$ro=mysqli_fetch_array($r);
     					$selectedcity=$ro['idCity'];
     				}



        $date=date('d-m-y');


   $sql = "INSERT INTO Advertisement (Category,Price,idCurrency,advertiser,Contacts,Zagolovok,Description,`Date`,City,Seller,email) VALUES ('$kategoria', '$sena', '$valyuta','$login_session','$number','$zagolovok','$opisanie','$date','$selectedcity','$imya','$email')";








        if ($result=mysqli_query($link, $sql))
        {

             $sq="SELECT * FROM Advertisement order by id_Ad desc limit 1";
     $sq2=mysqli_query($link,$sq);
     $posl=mysqli_fetch_array($sq2);

           $ph="SELECT * FROM Photos order by id_Photos desc limit 1";
     $ph2=mysqli_query($link,$ph);
     $pho=mysqli_fetch_array($ph2);
     $idad=$posl[0];
     $idpho=$pho[0]+1;


// проверяем, что есть файл
if((!empty($_FILES['kartinka'])) && ($_FILES['kartinka']['error'] == 0)) {
  // проверяем, что файл это изображение JPEG и его размер не больше 350кб
  $filename = basename($_FILES['kartinka']['name']);
  $ext = substr($filename, strrpos($filename, '.') + 1);
  if (($ext == 'jpg' || $ext == 'png') && ($_FILES['kartinka']['type'] == 'image/jpeg')) {
    // путь для сохранения файла
      $newname = dirname(__FILE__).'/Image/'.$idad.'_'.$idpho.'_'.$filename;
      $kartinka='/Image/'.$idad.'_'.$idpho.'_'.$filename;
      // проверяем, файл с таким названием уже есть на сервере
      if (!file_exists($newname)) {
        // переместить загруженный файл в новое место
        if ((move_uploaded_file($_FILES['kartinka']['tmp_name'],$newname))) {
         //  echo "Прелестно, файл был загружен: ".$newname;
        } else {
       //    echo "Произошла ошибка при загрузке файла!";
        }
      } else {
     //    echo "Ошибка: файл ".$_FILES['kartinka']['name']." уже существует";
      }
  } else {
   //  echo "Ошибка при загрузке файла, изображение не .jpg или больше чем 350кб.";
  }
} else {
 //echo "Ошибка: файл не загружен!";
}




            $addfoto="INSERT INTO Photos (id_Advertisement,Photo,Status) VALUES ('$posl[0]','$kartinka',1)";
            $sq2=mysqli_query($link,$addfoto);
    
                 header("Location:http://chacha:81/");
        exit();
      }
else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}







     
?>
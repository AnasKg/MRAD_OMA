<?php
if (isset($_POST['knopka']))
	{
$vyborcatt=$_POST['knopka'];
echo "Super";
}
/*$link = mysqli_connect("127.0.0.1", "root", "", "SaitOB");
 
// Check connection
if($link === false){
	echo "Сайт временно не доступен!";
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
									
			   						$vyborcat=$_POST;
                                    $zaprosRazdel="SELECT * FROM `Section` INNER JOIN `Category` ON `Section`.`id_section` = `Category`.`idSection` WHERE `Section`.`Section` = '".$vyborcat."'";

                                      $resultRazdel = mysqli_query($link, $zaprosRazdel);
                                      return $resultRazdel;

*/
?>
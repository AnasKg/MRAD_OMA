<?
include('C:\OSPanel\domains\Chacha\Add\dop.php');
		$vyborcat="";
	if (isset($_POST['knopka']))
	{
		$connection1 = mysqli_connect("127.0.0.1", "root", "", "SaitOB");
 		$Category2=$_POST['knopka'];
// Check connection
		if($connection1 === false){
				echo "Сайт временно не доступен!";
				echo "BAZA";
			}
			else 
			{
				$zaproszapros="SELECT * FROM Section WHERE Section='".$Category2."'";
				if (mysqli_query($connection1,$zaproszapros))
				{
					$vyborcat=$Category2;
					echo "Super $zaproszapros";
				}
				else {
					echo "zapros ne ochen' $Category2";
				}
			}
	}
	else {
		echo "Nepriwlo";
		$vyborcat="";
	}
?>
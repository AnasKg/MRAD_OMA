<?php
session_start();
$errorforemail='';
$errorforphonenumber='';
//if (isset($_POST['phonenumber'])){
if (isset($_POST['phonenumber']) and isset($_POST['email']))
	{
//$success_phonenumber=false;
//$success_email=false;
$link = mysqli_connect("127.0.0.1", "root", "", "SaitOB");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
$phonenumber = $_POST['phonenumber'];
//echo $phonenumber;
$email = $_POST['email'];
//echo $email;
$username = $_POST['username'];
$password = $_POST['password'];
$flajok="99";
$request1="SELECT `Number` from user where `Number`='".$phonenumber."'";
$request2="SELECT Email from user where Email='".$email."'";
$result_of_request1=mysqli_query($link,$request1);
$row_of_users1=mysqli_num_rows($result_of_request1);
$result_of_request2=mysqli_query($link,$request2);
$row_of_users2=mysqli_num_rows($result_of_request2);
//echo $row_of_users1;
if ($row_of_users1===0 && $row_of_users2===0){
$sql = "INSERT INTO user (`Number`, Email, password,username) VALUES ('$phonenumber', '$email', '$password','$username')";
$zareg="SELECT * FROM user WHERE `Number`=".$phonenumber."";
if(mysqli_query($link, $sql) ){
			$flajok="00";
			echo $flajok;
			$_SESSION['login_user']=$phonenumber;
    		//header("Location:http://chacha:81/");
    		//exit();

} else{
    echo "02";
}
 }
else {
 	if ($row_of_users1!=0 and $row_of_users2!=0 ){
 			echo "11";
 		}
 		else if ($row_of_users1!=0){
 			echo "10";
 		}
 		else if ($row_of_users2!=0){
 			echo "01";
 		}
 		//else {echo $flajok;}
 		
 	}
 
mysqli_close($link);
//}
//else {
//	var_dump("Error");
//}

}
else {
	echo "88";
}

?>
<!doctype html>
<html lang="en">
  <head>
    <title>Регистрация</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="Style.css">

    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
-->

  </head>
  <body>

 <div class="container">
      <div class="row">
        <div class="col">
          <center>
          <h2 class="col zag">Регистрация</h2>
        </center>
        </div>
      </div>
    </div>
    <div class="container">
       <div class="row">
          <div class="col">
            <div class="reg">
              <center>
                <form method="post" action="tempex.php">

                        

                  <div class="form-group row">
                    <label for="phonenumber" class="col-3 col-form-label" style="text-align: right;">Мобильный телефон<span class="zvezd">*</span></label>
                      <div class="col-6">
                        <input class="form-control" type="text" id="phonenumber" name="phonenumber" >
                        <span><?echo $errorforphonenumber;?></span>
                       </div>
                  </div>

                   <div class="form-group row">
                    <label for="email" class="col-3 col-form-label" style="text-align: right;">Email<span class="zvezd">*</span></label>
                      <div class="col-6">
                         <input type="email" class="form-control" id="email" name="email" value="" placeholder="name@example.com">
                         <span><?echo $errorforemail;?></span>
                       </div>
                  </div>

                  	<div class="form-group row">
                    <label for="username" class="col-3 col-form-label" style="text-align: right;">Username<span class="zvezd">*</span></label>
                      <div class="col-6">
                        <input class="form-control" type="text" id="username" name="username">
                       </div>
                  </div>
                  		<div class="form-group row">
                    <label for="password" class="col-3 col-form-label" style="text-align: right;">Пароль<span class="zvezd">*</span></label>
                      <div class="col-6">
                        <input class="form-control" type="password" id="password" name="password">
                       </div>
                  </div>

                  <div class="form-group row">
                    <label for="confirmpassword" class="col-3 col-form-label" style="text-align: right;">Подтвердите прароль<span class="zvezd">*</span></label>
                      <div class="col-6">
                        <input class="form-control" type="password" id="podpassword" name="confirmpassword">
                       </div>
                  </div>
                  


                 
            <input type="submit" class="btn btn-success" name="submit" value="submit">
        </form>
    </center>
         </div>
   </div>
  </div> 
</div>


 <!-- 

     <script src="jav.js"></script>

-->   


 <script src="jquery-3.2.1.js"></script>
    
    <script src="jscrit.js"></script>
    
        
  </body>
  </html>
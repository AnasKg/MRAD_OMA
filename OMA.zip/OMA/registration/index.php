<!doctype html>
<html lang="en">
  <head>
    <title>Регистрация</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="Style.css">

    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
-->

  </head>
  <body>

 <div class="container">
      <div class="row">
        <div class="col">
          <center>
          <h2 class="col zag">Регистрация</h2>
        </center>
        </div>
      </div>
    </div>
    <div class="container">
       <div class="row">
          <div class="col">
            <div class="reg">
              <center>
                <form method="post" action=""><br>

                        

                  <div class="form-group row">
                    <label for="phonenumber" class="col-3 col-form-label" style="text-align: right;">Мобильный телефон<span class="zvezd">*</span></label>
                      <div class="col-6">
                        <input class="form-control" type="text" id="phonenumber" name="phonenumber" >
                        <span><?echo $errorforphonenumber;?></span>
                       </div>
                  </div>

                   <div class="form-group row">
                    <label for="email" class="col-3 col-form-label" style="text-align: right;">Email<span class="zvezd">*</span></label>
                      <div class="col-6">
                         <input type="email" class="form-control" id="email" name="emaill" value="" placeholder="name@example.com">
                         <span><?echo $errorforemail;?></span>
                       </div>
                  </div>

                  	<div class="form-group row">
                    <label for="username" class="col-3 col-form-label" style="text-align: right;">Username<span class="zvezd">*</span></label>
                      <div class="col-6">
                        <input class="form-control" type="text" id="username" name="username">
                       </div>
                  </div>
                  		<div class="form-group row">
                    <label for="password" class="col-3 col-form-label" style="text-align: right;">Пароль<span class="zvezd">*</span></label>
                      <div class="col-6">
                        <input class="form-control" type="password" id="password" name="password">
                       </div>
                  </div>

                  <div class="form-group row">
                    <label for="confirmpassword" class="col-3 col-form-label" style="text-align: right;">Подтвердите прароль<span class="zvezd">*</span></label>
                      <div class="col-6">
                        <input class="form-control" type="password" id="podpassword" name="confirmpassword">
                       </div>
                  </div>
                  


                 
            <button type="button" class="btn btn-success" id="reg" onclick="registrasia(this.form)">Регистрация</button>
        </form>
    </center>
         </div>
   </div>
  </div> 
</div> 


 <script src="jquery-3.2.1.js"></script>
    
   <!-- <script src="jscrit.js"></script>-->
    
    <script>
      function showError(container,input, errorMessage) {
      container.className = 'form-group has-danger col-6';
      input.className='form-control form-control-danger';
      var msgElem = document.createElement('small');
      msgElem.className = "form-control-feedback";
      msgElem.innerHTML = errorMessage;
      container.appendChild(msgElem);
    };


function resetError(container,input) {
      container.className = 'col-6';
      input.className='form-control';
      if (container.lastChild.className == "form-control-feedback") {
        container.removeChild(container.lastChild);
      }
    };
function registrasia(form){
    
    
    //function validate(form){
      var flag=0;
      var elems = form.elements;
      resetError(elems.phonenumber.parentNode,elems.phonenumber);
      if (!elems.phonenumber.value){
        showError(elems.phonenumber.parentNode,elems.phonenumber,'Укажите номер.');
        flag=1;
      }
      resetError(elems.email.parentNode,elems.email);
      if (!elems.email.value){
        showError(elems.email.parentNode,elems.email,'Укажите свой email.');
        flag=1;
      }
      resetError(elems.username.parentNode,elems.username);
      if (!elems.username.value){
        showError(elems.username.parentNode,elems.username,'Укажите свой username');
        flag=1;
      }
      resetError(elems.password.parentNode,elems.password);
      if (!elems.password.value){
        showError(elems.password.parentNode,elems.password,'Укажите пароль.');
        flag=1;
      }
      else if (elems.password.value != elems.confirmpassword.value){
        showError(elems.password.parentNode,elems.password,'Пароли не совпадают.');
        flag=1;
      }
      if (flag==0)
      {
        resetError(elems.password.parentNode,elems.password);
        resetError(elems.username.parentNode,elems.username);
        resetError(elems.email.parentNode,elems.email);
        resetError(elems.phonenumber.parentNode,elems.phonenumber);
            alert(elems.phonenumber.value);
            $.ajax({
                  type: "POST",
                  url: "reg.php",
                  data:{'phonenumber':elems.phonenumber.value, 'email':elems.email.value, 'username':elems.username.value, 'password':elems.password.value},
                  success:function(data)
                  {
                    alert(data);
                        if (data=="01")
                        {
                              showError(elems.email.parentNode,elems.email,'Такой email уже существует.');
                                    flag=1;
                                    alert(data);
                        }
                        else if (data=="10")
                        {
                              showError(elems.phonenumber.parentNode,elems.phonenumber,'Такой номер уже существует.');
                                    flag=1;
                                    alert(data);
                        }
                        else if (data=="11")
                        {
                              showError(elems.phonenumber.parentNode,elems.phonenumber,'Такой номер уже существует.');
                              showError(elems.email.parentNode,elems.email,'Такой email уже существует.');
                                    flag=1;
                                    alert(data);
                        }
                        else if (data=="00")
                        {
                              alert("Super");
                              alert(data);
                              
                              window.location="http://chacha:81/";
                        }
                        else if (data=="99")
                        {
                              alert("Ehh");
                              alert(data);
                        }
                        else if (data=="88")
                        {
                              alert("yoooooooooo");
                              alert(data);
                        }
                  },
                  error:function()
                  {
                        alert("error");
                  }
            });
      }


 // }

};
    </script>
  
  </body>
  </html>
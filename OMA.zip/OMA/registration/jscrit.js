function showError(container,input, errorMessage) {
      container.className = 'form-group has-danger col-6';
      input.className='form-control form-control-danger';
      var msgElem = document.createElement('small');
      msgElem.className = "form-control-feedback";
      msgElem.innerHTML = errorMessage;
      container.appendChild(msgElem);
    };


function resetError(container,input) {
      container.className = 'col-6';
      input.className='form-control';
      if (container.lastChild.className == "form-control-feedback") {
        container.removeChild(container.lastChild);
      }
    };
function registrasia(form){
		
    
    //function validate(form){
    	var flag=0;
      var elems = form.elements;
      resetError(elems.phonenumber.parentNode,elems.phonenumber);
      if (!elems.phonenumber.value){
      	showError(elems.phonenumber.parentNode,elems.phonenumber,'Укажите номер.');
      	flag=1;
      }
      resetError(elems.email.parentNode,elems.email);
      if (!elems.email.value){
      	showError(elems.email.parentNode,elems.email,'Укажите свой email.');
      	flag=1;
      }
      resetError(elems.username.parentNode,elems.username);
      if (!elems.username.value){
      	showError(elems.username.parentNode,elems.username,'Укажите свой username');
      	flag=1;
      }
      resetError(elems.password.parentNode,elems.password);
      if (!elems.password.value){
      	showError(elems.password.parentNode,elems.password,'Укажите пароль.');
      	flag=1;
      }
      else if (elems.password.value != elems.confirmpassword.value){
      	showError(elems.password.parentNode,elems.password,'Пароли не совпадают.');
      	flag=1;
      }
      if (flag==0)
      {
            alert(elems.phonenumber.value);
            $.ajax({
                  type: "POST",
                  url: "reg.php",
                  data:{'phonenumber':elems.phonenumber.value, 'email':elems.email.value, 'username':elems.username.value, 'password':elems.password.value},
                  success:function(data)
                  {
                        if (data=="01")
                        {
                              showError(elems.email.parentNode,elems.email,'Такой email уже существует.');
                                    flag=1;
                        }
                        else if (data=="10")
                        {
                              showError(elems.phonenumber.parentNode,elems.phonenumber,'Такой номер уже существует.');
                                    flag=1;
                        }
                        else if (data=="11")
                        {
                              showError(elems.phonenumber.parentNode,elems.phonenumber,'Такой номер уже существует.');
                              showError(elems.email.parentNode,elems.email,'Такой email уже существует.');
                                    flag=1;
                        }
                        else if (data=="00")
                        {
                              window.location="http://chacha:81/";
                              alert("Super");
                        }
                        else if (data=="99")
                        {
                              alert("Ehh");
                        }
                        else if (data=="88")
                        {
                              alert("yoooooooooo");
                        }
                  },
                  error:function()
                  {
                        alert("error");
                  }
            });
      }


 // }

};